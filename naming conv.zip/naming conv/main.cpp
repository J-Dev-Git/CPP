#include <iostream>
using namespace std; //helps to get rid of the std::


int main() {

    int num = 0;
    cout << "please enter a number \n";
    cin >> num; //character input
    cout << "The number you have entered is: \n";
    cout << num;

    return 0;
}
