#include <iostream>

int main(){

    //if you do not want to change var
    //const constant
    const double number = 5;//you cannot change this value no more

    number = 2; //shows error

    return 0;
};