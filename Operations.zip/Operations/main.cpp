#include <iostream>
using namespace std;

int main() {

    int num1 , num2 ;

    cout << "Please enter your number\n";
    cin >> num1;
    cout << "Please enter the second number\n";
    cin >> num2;

    num1 += num2;

    cout << "The total of the numbers are\n";
    cout << num1;

    return 0;

}
