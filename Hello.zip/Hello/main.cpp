#include <iostream>
//input output stream

int main(){

    double number_integer = 0; //store integer
    double number_decimal = 0;

    number_integer = 19;
    number_decimal = 12.99;
    double temp = 0;

    std::cout << number_integer; //its not going to output
    std::cout << number_decimal; //it is not initialized

    std::cout << " Then ";

    temp = number_integer;
    number_integer = number_decimal;
    number_decimal = temp;


    std::cout << number_integer; //swapped result
    std::cout << number_decimal;


    //std:: cout << "Hello World!";
    //std standard library
    //cout character output

    return 0;

}