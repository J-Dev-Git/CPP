#include <iostream>
#include <string>
using namespace std;

int main() {

    string name ("Joynal");
    int num (2);
    auto hex(0x4b); // this is considered as 75, because from hex to decimal
    auto a = 12.6f + 13;
    const char space = '\n';
    string hello("hello" "Miaowe") ;


    cout << name << endl;
    cout << "My name is " + name << endl;
    cout << hex << endl;
    cout << space;
    cout << a << endl;
    cout << hello;

    return 0;
}
