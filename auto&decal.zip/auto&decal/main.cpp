#include <iostream>
using namespace std;

int main() {

    char32_t test = 4000000000; //adding one more number, will not store in this data type, the limit is at 4bil
    auto num = 1;//automatically "auto" determines the data type
    auto name = "Joynal";
    auto store = {"hello", "miaow"};
    auto number (3);//you can write it this way so that it is a bit cleaner


    decltype(num) bar;// usage in case of having a long data type to write
    bar = 5;

    cout << num;

    return 0;

}
